#include <stdio.h>
#include <stdlib.h>
#include "homar.h"

int main()
{   struct object *objects;
    int no_objects;
    int net_capacity = 0;

    printf("Capacitatea plasei: ");
    scanf("%d",&net_capacity);
    printf("Nr de homari disponibili: ");
    scanf("%d",&no_objects);
    objects = malloc(no_objects * sizeof(struct object));
    generate_objects(objects, no_objects);
    printf("\n=== Random homar ===");
    print_objects(objects, no_objects);
    sort_homar_by_value(objects, no_objects);
    printf("\n=== Sorted homar ===");
    print_objects(objects, no_objects);
    greedy_homar_discrete(objects, no_objects, net_capacity);

    return 0;
}
