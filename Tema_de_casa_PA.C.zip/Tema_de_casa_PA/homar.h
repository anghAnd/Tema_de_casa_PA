#ifndef HOMAR_H
#define HOMAR_H

struct object{
    int id;
    int size;
    int value;
};

void generate_objects(struct object *objects, int no_objects);
void print_objects(struct object *objects, int no_objects);
void sort_homar_by_value(struct object *objects, int no_objects);
void greedy_homar_discrete(struct object *objects, int no_objects, int net_capacity);



#endif
