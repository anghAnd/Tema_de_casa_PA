import random
import time

class Object:
    def __init__(self, obj_id, size, value):
        self.id = obj_id
        self.size = size
        self.value = value

def generate_objects(no_objects):
    random.seed(time.time())  # Initialize random number generator
    objects = []
    for i in range(no_objects):
        obj_id = i
        size = random.randint(1, 50)  # Random size between 1 and 50
        value = random.randint(1, 50)  # Random value between 1 and 50
        objects.append(Object(obj_id, size, value))
    return objects

def print_objects(objects):
    print("\nHomari disponibili:")
    for obj in objects:
        print(f"Homarul: {obj.id}    Dimensiune: {obj.size} cm    Valoare: {obj.value} monede de aur")

def sort_homar_by_value(objects):
    objects.sort(key=lambda obj: obj.value, reverse=True)

def greedy_homar_discrete(objects, net_capacity):
    net_current_capacity = 0
    net_value = 0
    sort_homar_by_value(objects)
    print("\nHomarii alesi de pescar sunt: ")
    for i, obj in enumerate(objects):
        if net_current_capacity + obj.size <= net_capacity:
            net_current_capacity += obj.size
            net_value += obj.value
            if i != len(objects) - 1:
                print(f"{obj.id}, ", end='')
            else:
                print(f"{obj.id}.")
    print(f"\nValoarea pestelui din plasa de pescuit: {net_value}")

def main():
    net_capacity = int(input("Capacitatea plasei: "))
    no_objects = int(input("Nr de homari disponibili: "))
    
    objects = generate_objects(no_objects)
    print("\n=== Random homar ===")
    print_objects(objects)
    
    sort_homar_by_value(objects)
    print("\n=== Sorted homar ===")
    print_objects(objects)
    
    greedy_homar_discrete(objects, net_capacity)

if __name__ == "__main__":
    main()